public class Gift
{
    private String name;
    private String giftHolder;
    private int numStolen;
    
    public Gift(String n)
    {
        name = n;
        giftHolder = "";
        numStolen = 0;
    }
    
    public void setGiftHolder(String x)
    {
        giftHolder = x;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getGiftHolder()
    {
        return giftHolder;
    }
    
    public int getNumStolen()
    {
        return numStolen;
    }
    
    public boolean stolen()
    {
        if (numStolen < 3)
        {
            numStolen++;
            return true;
        }
        
        else
        {
            System.out.println("***This item has been stolen three times already. Choose a different option***");
            return false;
        }
    }
    
    public String toString()
    {
        return "Name: " + name + "\nGift Holder: " + giftHolder + "\nNum Stolen: " + numStolen;
    }
    
}
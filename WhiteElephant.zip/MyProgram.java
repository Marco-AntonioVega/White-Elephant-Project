/*
*Name: White Elephant Project
*Author: Marco-Antonio Vega
*Date: December 9, 2019
*Summary: This program simulates a round of White Elephant with 5 players and 5 gifts. Players will choose gifts in random order, and every player (besides player #1) can choose if they want to steal a gift or pick a new unopened gift from the pile.  
*/
import java.util.*;
public class MyProgram extends ConsoleProgram
{
    //this creates static arrayLists that the whole program can see
    static ArrayList<String> names = new ArrayList<String>();
    static ArrayList<Gift> unopenedGifts = new ArrayList<Gift>();
    static ArrayList<Character> letters = new ArrayList<Character>();
    static ArrayList<Gift> openedGifts = new ArrayList<Gift>();
    static int index = 0;
    
    public void run()
    {
        int player = 0;
        
        names.add("Marco");
        names.add("Diego");
        names.add("Steven");
        names.add("Evan");
        names.add("Austin");
        
        Gift airpods = new Gift("airpods");
        Gift book = new Gift("book");
        Gift car = new Gift("car");
        Gift dog = new Gift("dog");
        Gift elephant = new Gift("elephant");
        
        unopenedGifts.add(airpods);
        unopenedGifts.add(book);
        unopenedGifts.add(car);
        unopenedGifts.add(dog);
        unopenedGifts.add(elephant);
        
        letters.add('A');
        letters.add('B');
        letters.add('C');
        letters.add('D');
        letters.add('E');
        
        printDirections();
        
        System.out.println("\nHere are our players: " + names);
        System.out.println("\nOur list of gifts: \nairpods\nbook\ncar\ndog\nelephant");
        Collections.shuffle(names);
        System.out.println("\nThe order in which the players will choose: " + names);
        
        //Collections.shuffle(unopenedGifts);
        
        //ensures first person is not given the choice to steal
        while (openedGifts.isEmpty())
        {
            pickUnopenedGift(player);
            player++;
        }
        
        //gives other player the chance to steal
        while (!unopenedGifts.isEmpty())
        {
            System.out.println("It is " + names.get(player) + "'s turn!\n");
            boolean check = false;
            while (check == false)
            {
                String action = readLine("Do you want to choose an unopened gift or steal from another player? Enter 'steal' or 'open': ");
                if (action.equalsIgnoreCase("open"))
                {
                    pickUnopenedGift(player);
                    player++;
                    check = true;
                }
                
                //steals gift and gives the player that was 
                //stolen from another chance to open gift
                else if (action.equalsIgnoreCase("steal"))
                {
                    String openAgain = stealOpenGift(player);
                    int nextPlayer = 0;
                    for (int i = 0; i < names.size(); i++)
                    {
                        if (names.get(i).equals(openAgain))
                        {
                            nextPlayer = player;
                            player = i;
                            pickUnopenedGift(player);
                        }
                    }
                    //integer goes to next player in line
                    player = nextPlayer + 1;
                    check = true;
                }
            
                else
                {
                    System.out.println("Please choose a correct option\n");
                }
            }
            
        }
        
        System.out.println("That's the end of the game!");   
    }
    
    public void printDirections()
    {
        System.out.println("~~~**Welcome to our White Elephant Game!**~~~");
        System.out.println("This is a game where you never know which gift you will end up with.");
        System.out.println("Here's how to play the game:");
        System.out.println("Everyone has placed their gifts in the middle of the room");
        System.out.println("and has been given a number.");
        System.out.println("This number determines when you will be picking a gift from");
        System.out.println("the pile.");
        System.out.println("When it is your turn, you have two choices:");
        System.out.println("pick a gift from the pile or steal someone else's gift!");
        System.out.println("Here's the catch: each gift can only be stolen");
        System.out.println("3 times during the game. So choose wisely!");
        System.out.println("Good luck");
    }
    
    //picks unopened gift
    public void pickUnopenedGift(int currentPlayer)
    {
        if (openedGifts.isEmpty())
        {
            System.out.println("It is " + names.get(currentPlayer) + "'s turn!\n");   
        }
        
        boolean check = false;
        
        while (check == false)
        {
            String choice = readLine("\n" + names.get(currentPlayer) + ", enter one of the following letters to represent your choice " + letters + ": ");
            choice = choice.toUpperCase();
            char letter = choice.charAt(0);
            if (letters.contains(letter))
            {
                //checks if choice is in the choice index
                index = letters.indexOf(letter);
                System.out.println("You picked the " + unopenedGifts.get(index).getName() + "!\n");
                
                if (unopenedGifts.get(index).getName().equals("airpods"))
                {
                    unopenedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                    openedGifts.add(unopenedGifts.get(index));
                    unopenedGifts.remove(unopenedGifts.get(index));
                    letters.remove(index);
                }
        
                else if (unopenedGifts.get(index).getName().equals("book"))
                {
                    unopenedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                    openedGifts.add(unopenedGifts.get(index));
                    unopenedGifts.remove(unopenedGifts.get(index));
                    letters.remove(index);
                }
                
                else if (unopenedGifts.get(index).getName().equals("car"))
                {
                    unopenedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                    openedGifts.add(unopenedGifts.get(index));
                    unopenedGifts.remove(unopenedGifts.get(index));
                    letters.remove(index);
                }
                
                else if (unopenedGifts.get(index).getName().equals("dog"))
                {
                    unopenedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                    openedGifts.add(unopenedGifts.get(index));
                    unopenedGifts.remove(unopenedGifts.get(index));
                    letters.remove(index);
                }
                
                else if (unopenedGifts.get(index).getName().equals("elephant"))
                {
                    unopenedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                    openedGifts.add(unopenedGifts.get(index));
                    unopenedGifts.remove(unopenedGifts.get(index));
                    letters.remove(index);
                }
                check = true;
            }
            
            else
            {
                System.out.println("Please enter a correct option\n");
            }
        } 
    }
    
    //steals gift
    public String stealOpenGift(int currentPlayer)
    {
        String previousHolder = "";
        boolean check = false;
        
        while (check == false)
        {
            System.out.println("");
            for (int i = 0; i < openedGifts.size(); i++)
            {
                System.out.println(openedGifts.get(i).getName());
            }
            
            int index = 50;
            
            //check if gift to steal is available
            while (index == 50)
            {
                String whatToSteal = readLine("\n" + names.get(currentPlayer) + ", choose which item from the list you would like to steal: ");
                for (int i = 0; i < openedGifts.size(); i++)
                {
                    if (openedGifts.get(i).getName().equals(whatToSteal.toLowerCase()))
                    {
                        index = i;
                    }
                }
                
                if (index == 50)
                {
                    System.out.println("Please choose a correct option");
                }
            }
            
            if (openedGifts.get(index).stolen())
            {
                System.out.println("You stole the " + openedGifts.get(index).getName());
                previousHolder = openedGifts.get(index).getGiftHolder();
                openedGifts.get(index).setGiftHolder(names.get(currentPlayer));
                
                check = true;
            }
            
            else
            {
                check = false;
            }
        }
        
        return previousHolder;
    }
}